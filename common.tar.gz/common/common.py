#
"""
common.py

anthology of handy modules and classes that find their
way into many of my processes.
"""
pass;