# python 27 versions!

turns out that some of the code needs to be ported to the older version:

main changes:

removing attribute documentation, and moving that to the main body of the
function.

# todo:

merge changes into one unified piece of source
