# Common

set of common functions that find their way into my code frequently.

Working on porting the code to work on older versions of python as 
well as it does on python 3.x

Currently looks like the files are now backwards compatible, so I'll
continue to modify them as more errors are encountered.
